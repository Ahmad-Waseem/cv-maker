import React from 'react';
import { motion } from 'framer-motion';
import './Homepage.css';

const HomePage = ({ onMakeCvClick }) => {
  return (
    <div className="homepage-container">
      <motion.header 
        className="homepage-header"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <h1>Build Your CV</h1>
        <p>Create a professional CV in just a few clicks.</p>
        <button className="make-cv-button" onClick={onMakeCvClick}>
          <span>Make Elite Resume</span>
        </button>
      </motion.header>
    </div>
  );
};

export default HomePage;
