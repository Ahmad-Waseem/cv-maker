import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './Homepage';
import DataEntry from './components/DataEntry';
import About from './pages/About';
import Projects from './pages/Projects';
import './App.css';

function App() {
  const [showDataEntry, setShowDataEntry] = useState(false);
  const [portfolioData, setPortfolioData] = useState(null);

  const handleMakeCvClick = () => {
    setShowDataEntry(true);
    // Scroll to the data entry form
    setTimeout(() => {
      const dataEntryElement = document.querySelector('.data-entry-container');
      if (dataEntryElement) {
        dataEntryElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const handlePortfolioSubmit = (data) => {
    setPortfolioData(data);
    console.log('Portfolio data received:', data);
  };

  return (
    <Router>
      <div className="App">
        <Navbar portfolioData={portfolioData} />
        <Routes>
          <Route 
            path="/" 
            element={
              <>
                <HomePage onMakeCvClick={handleMakeCvClick} />
                {showDataEntry && <DataEntry onSubmit={handlePortfolioSubmit} portfolioData={portfolioData} />}
              </>
            } 
          />
          <Route 
            path="/about" 
            element={<About portfolioData={portfolioData} />} 
          />
          <Route 
            path="/projects" 
            element={<Projects portfolioData={portfolioData} />} 
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
