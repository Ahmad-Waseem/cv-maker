import React, { useState } from 'react';
import { motion } from 'framer-motion';
import 'bootstrap/dist/css/bootstrap.min.css';
import './DataEntry.css';

const DataEntry = ({ onSubmit, portfolioData }) => {
  // Basic info
  const [Name, setName] = useState(portfolioData?.Name || '');
  const [bio, setBio] = useState(portfolioData?.bio || '');
  
  // About Me
  const [profilePic, setProfilePic] = useState(portfolioData?.profilePic || '');
  const [skills, setSkills] = useState(portfolioData?.skills || []);
  const [skillInput, setSkillInput] = useState('');
  const [interests, setInterests] = useState(portfolioData?.interests || '');
  const [aboutDesc, setAboutDesc] = useState(portfolioData?.aboutDesc || '');
  
  const [projects, setProjects] = useState(
    portfolioData?.projects || [{ title: '', description: '', image: '', github: '' }]
  );
  
  // Social Media
  const [socialLinks, setSocialLinks] = useState(
    portfolioData?.socialLinks || [{ name: '', url: '' }]
  );

  // Skill: on Enter, add the skill to the list.
  const handleSkillKeyDown = (e) => {
    if (e.key === 'Enter' && skillInput.trim()) {
      e.preventDefault();
      setSkills([...skills, skillInput.trim()]);
      setSkillInput('');
    }
  };

  // Remove a skill
  const handleRemoveSkill = (indexToRemove) => {
    setSkills(skills.filter((_, index) => index !== indexToRemove));
  };

  // Projects add &/or remove
  const handleAddProject = () => {
    setProjects([...projects, { title: '', description: '', image: '', github: '' }]);
  };

  const handleRemoveProject = (index) => {
    const newProjects = [...projects];
    newProjects.splice(index, 1);
    setProjects(newProjects);
  };

  const handleProjectChange = (index, field, value) => {
    const newProjects = [...projects];    // new array with the same projects
    newProjects[index][field] = value;
    setProjects(newProjects);
  };

  // Social media add & change
  const handleAddSocial = () => {
    setSocialLinks([...socialLinks, { name: '', url: '' }]);
  };

  const handleSocialChange = (index, field, value) => {
    const newSocial = [...socialLinks];
    newSocial[index][field] = value;
    setSocialLinks(newSocial);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Check form validity
    const form = e.target;
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    const proj_images = [
      "https://www.svgrepo.com/svg/235147/artificial-intelligence.svg",
      "https://www.svgrepo.com/svg/198469/artificial-intelligence.svg",
      "https://www.svgrepo.com/svg/535314/code.svg",
      "https://www.svgrepo.com/svg/530590/computer.svg",
      "https://www.svgrepo.com/svg/484788/information-part-2.svg",
      "https://www.svgrepo.com/svg/172667/time.svg",
      "https://www.svgrepo.com/svg/43151/mathematics.svg",
    ];

    const updatedProjects = projects.map(project => {
      if (!project.image) {
        const randomIndex = Math.floor(Math.random() * proj_images.length);
        return {
          ...project,
          image: proj_images[randomIndex]
        };
      }
      return project;
    });

    // portfolio data object
    const portfolioData = {
      Name,
      bio,
      profilePic,
      skills,
      interests,
      aboutDesc,
      projects: updatedProjects,
      socialLinks,
    };

    onSubmit(portfolioData);
    console.log(portfolioData);
  };

  return (
    <motion.div 
      className="data-entry-container flex-column"
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.h2 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <h2 className="text-center">Create Your Portfolio</h2>
      </motion.h2>
      <form className="data-entry-form" onSubmit={handleSubmit}>
        {/* ----------------------> Basic Info */}
        <section className="subpart">
          <motion.div 
            className="mb-4"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <h4 className="mb-3">Basic Info</h4>
            <div className="mb-3">
              <label className="form-label">Candidate Name</label>
              <input 
                type="text" 
                className="form-control" 
                value={Name} 
                onChange={(e) => setName(e.target.value)} 
                required 
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Bio</label>
              <textarea 
                className="form-control" 
                value={bio} 
                onChange={(e) => setBio(e.target.value)} 
                required 
              />
            </div>
          </motion.div>
        </section>
        <hr />

        {/* ----------------------> About Me Section */}
        <section className="subpart">
          <motion.div 
            className="mb-4"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <h4 className="mb-3">About Me</h4>
            <div className="mb-3">
              <label className="form-label">Profile Picture URL</label>
              <input 
                type="url" 
                className="form-control" 
                value={profilePic} 
                onChange={(e) => setProfilePic(e.target.value)} 
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Skills</label>
              <div className="skills-input-container">
                <input 
                  type="text" 
                  className="form-control" 
                  placeholder="Type a skill" 
                  value={skillInput} 
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={handleSkillKeyDown}
                  required={skills.length === 0}
                />
                <span className="skills-input-hint">Press Enter to add</span>
              </div>
              <div className="skills-box mt-2">
                {skills.map((skill, index) => (
                  <motion.span 
                    key={index} 
                    className="badge bg-info"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 500 }}
                  >
                    {skill}
                    <button 
                      className="skill-remove"
                      onClick={() => handleRemoveSkill(index)}
                    >
                      ×
                    </button>
                  </motion.span>
                ))}
              </div>
            </div>
            <div className="mb-3">
              <label className="form-label">Interests</label>
              <textarea 
                className="form-control" 
                value={interests} 
                onChange={(e) => setInterests(e.target.value)} 
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Detailed Description</label>
              <textarea 
                className="form-control" 
                value={aboutDesc} 
                onChange={(e) => setAboutDesc(e.target.value)} 
                required 
              />
            </div>
          </motion.div>
        </section>
        <hr />

        {/* ----------------------> Projects Section */}
        <section className="subpart projects-section">
          <motion.div 
            className="mb-4"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <h4 className="mb-3">Projects</h4>
            {projects.map((proj, index) => (
              <motion.div 
                key={index} 
                className="project-entry p-4"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.1 * index }}
              >
                <div className="mb-2 d-flex justify-content-between align-items-center">
                  <h5 className="mb-0">Project {index + 1}</h5>
                  {projects.length > 1 && (
                    <button 
                      type="button" 
                      className="btn btn-danger btn-sm"
                      onClick={() => handleRemoveProject(index)}
                    >
                      Remove
                    </button>
                  )}
                </div>
                <div className="mb-2">
                  <label className="form-label">Title</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    value={proj.title} 
                    onChange={(e) => handleProjectChange(index, 'title', e.target.value)} 
                    required 
                  />
                </div>
                <div className="mb-2">
                  <label className="form-label">Description</label>
                  <textarea 
                    className="form-control" 
                    value={proj.description} 
                    onChange={(e) => handleProjectChange(index, 'description', e.target.value)} 
                    required 
                  />
                </div>
                <div className="mb-2">
                  <label className="form-label">Image URL</label>
                  <input 
                    type="url" 
                    className="form-control" 
                    value={proj.image} 
                    onChange={(e) => handleProjectChange(index, 'image', e.target.value)} 
                  />
                </div>
                <div className="mb-2">
                  <label className="form-label">GitHub Link</label>
                  <input 
                    type="url" 
                    className="form-control" 
                    value={proj.github} 
                    onChange={(e) => handleProjectChange(index, 'github', e.target.value)} 
                    required
                  />
                </div>
              </motion.div>
            ))}
            <button 
              type="button" 
              className="btn btn-primary mt-3"
              onClick={handleAddProject}
            >
              +
            </button>
          </motion.div>
        </section>
        <hr />

        {/* ---------------------->  Social Media Section */}
        <section className="subpart">
          <motion.div 
            className="mb-4"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <h4 className="mb-3">Social Media</h4>
            {socialLinks.map((soc, index) => (
              <div key={index} className="mb-3">
                <label className="form-label">Platform Name</label>
                <input 
                  type="text" 
                  className="form-control" 
                  value={soc.name} 
                  onChange={(e) => handleSocialChange(index, 'name', e.target.value)} 
                  required
                />
                <label className="form-label mt-2">URL</label>
                <input 
                  type="url" 
                  className="form-control" 
                  value={soc.url} 
                  onChange={(e) => handleSocialChange(index, 'url', e.target.value)} 
                  required
                />
              </div>
            ))}
            <button 
              type="button" 
              className="btn btn-primary"
              onClick={handleAddSocial}
            >
              Add Social Media
            </button>
          </motion.div>
        </section>
        
        <div className="text-center mt-5">
          <button 
            type="submit" 
            className="btn btn-animated btn-lg"
          >
            <span>Generate Magic</span>
          </button>
        </div>
      </form>
    </motion.div>
  );
};

export default DataEntry;
