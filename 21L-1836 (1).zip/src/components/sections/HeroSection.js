import React from 'react';
import { motion } from 'framer-motion';

const HeroSection = ({ Name, bio }) => {
  return (
    <div className="hero-section py-5">
      <div className="container">
        <div className="row align-items-center">
          <div className="col-lg-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="display-4 fw-bold mb-4">Hi, It's {Name}</h1>
              <p className="lead mb-4">{bio}</p>
              <button className="btn-animated rounded-pill" style={{ backgroundColor: 'none' }}>
                <span>View My Work</span>
              </button>
            </motion.div>
          </div>
          <div className="col-lg-6">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-center"
            >
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection; 