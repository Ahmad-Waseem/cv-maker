import React from 'react';
import { motion } from 'framer-motion';

const AboutSection = ({ profilePic, skills, description }) => {
  return (
    <div className="about-section py-5">
      <div className="container">
        <div className="row">
          <div className="col-lg-4 mb-4 mb-lg-0">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <img
                src={profilePic}
                alt="Profile"
                className="img-fluid rounded-circle mb-4"
                style={{ maxWidth: '250px', margin: '0 auto' }}
              />
            </motion.div>
          </div>
          <div className="col-lg-8">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h2 className="mb-4">About Me</h2>
              <p className="lead mb-4">{description}</p>
              
              <h3 className="mb-3">Skills</h3>
              <div className="d-flex flex-wrap gap-2">
                {skills.map((skill, index) => (
                  <motion.span
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="badge bg-primary"
                  >
                    {skill}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutSection; 