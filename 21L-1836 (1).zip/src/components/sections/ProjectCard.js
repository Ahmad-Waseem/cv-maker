import React from 'react';
import { Draggable } from 'react-beautiful-dnd';
import './ProjectCard.css';


/* This Project Card Component is inspired by https://uiverse.io/Smit-Prajapati/stupid-bullfrog-39  :)*/
const ProjectCard = ({ project, index }) => {
  return (
    <Draggable draggableId={project.id} index={index}>
      {(provided) => (
        <div
          className="project-card"
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
        >
          {/* Instead of "Contact Me" button, we use a hover-triggered button
              that shows the GitHub icon linking to the project's GitHub URL */}
          <button 
            className="github-button"
            onClick={(e) => e.stopPropagation()}  // prevent dragging when clicking
          >
            <a href={project.github} target="_blank" rel="noopener noreferrer">
              <i className="fab fa-github"></i>
            </a>
          </button>

          {/* Profile picture replaces SVG */}
          <div className="profile-pic">
            <img src={project.image} alt={project.title} />
          </div>

          {/* Bottom overlay containing the project title 
                (replacing "Contact me" text),
              description (scrollable if too long) 
              and tech stack */}
          <div className="bottom">
            <div className="content">
              <span className="name">{project.title}</span>
              <span className="description-container">
                <p>{project.description}</p>
              </span>
              {project.techStack && project.techStack.length > 0 && (
                <div className="tech-stack">
                  {project.techStack.map((tech, i) => (
                    <span key={i} className="tech-badge">
                      {tech}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </Draggable>
  );
};

export default ProjectCard;
