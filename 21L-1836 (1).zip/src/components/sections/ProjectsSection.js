import React, { useState, useEffect } from 'react';
import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import ProjectCard from './ProjectCard';
import './ProjectsSection.css';

const ProjectsSection = ({ portfolioData }) => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProjectData = async () => {
      try {
        if (portfolioData?.projects) {
          const extraInfoProjects = await Promise.all(
            portfolioData.projects.map(async (project) => {
              try {
                const githubUrl = project.github;
                const [owner, repo] = githubUrl
                  .replace('https://github.com/', '')
                  .split('/');

                const repoResponse = await fetch(`https://api.github.com/repos/${owner}/${repo}`);
                const repoData = await repoResponse.json();

                const languagesResponse = await fetch(`https://api.github.com/repos/${owner}/${repo}/languages`);
                const languagesData = await languagesResponse.json();

                const techStack = Object.keys(languagesData);

                return {
                  id: project.id || Math.random().toString(),
                  title: project.title,
                  description: project.description,
                  image: project.image,
                  github: project.github,
                  techStack,
                  stars: repoData.stargazers_count
                };
              } catch (error) {
                console.error('Error fetching project data:', error);
                return {
                  id: project.id || Math.random().toString(),
                  title: project.title,
                  description: project.description,
                  image: project.image,
                  github: project.github,
                  techStack: [],
                  stars: 0
                };
              }
            })
          );

          setProjects(extraInfoProjects);
        }
      } catch (error) {
        console.error('Error fetching projects:', error);
        setProjects(portfolioData?.projects || []);
      } finally {
        setLoading(false);
      }
    };

    fetchProjectData();
  }, [portfolioData]);

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(projects);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setProjects(items);
  };

  if (loading) {
    return (
      <div className="projects-loading">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="projects-section">
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="projects">
          {(provided) => (
            <div
              className="projects-grid"
              {...provided.droppableProps}
              ref={provided.innerRef}
            >
              {projects.map((project, index) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  index={index}
                />
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};

export default ProjectsSection; 