import React from 'react';
import ProjectsSection from '../components/sections/ProjectsSection';
import './Projects.css';

const Projects = ({ portfolioData }) => {
  return (
    <div className="projects-page">
      <div className="projects-container">
        <h2 className="text-center mb-5">My Projects</h2>
        <ProjectsSection portfolioData={portfolioData} />
      </div>
    </div>
  );
};

export default Projects; 