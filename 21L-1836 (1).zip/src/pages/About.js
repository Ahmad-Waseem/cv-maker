import React from 'react';
import HeroSection from '../components/sections/HeroSection';
import AboutSection from '../components/sections/AboutSection';
import './About.css';

const About = ({ portfolioData }) => {
  return (
    <div className="about-page">
      <HeroSection 
        studentName={portfolioData?.Name || 'Anonymous'} 
        bio={portfolioData?.bio || 'Welcome to my portfolio!'} 
      />
      <AboutSection 
        profilePic={portfolioData?.profilePic || 'https://www.svgrepo.com/show/535385/face-smile.svg'} 
        skills={portfolioData?.skills || []} 
        description={portfolioData?.aboutDesc || 'I am someone who knows the job :)'} 
      />
    </div>
  );
};

export default About; 